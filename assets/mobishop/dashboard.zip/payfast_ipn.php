<?php
// Tell PayFast that this page is reachable by triggering a header 200
header( 'HTTP/1.0 200 OK' );
flush();

define( 'SANDBOX_MODE', false );
$pfHost = SANDBOX_MODE ? 'sandbox.payfast.co.za' : 'www.payfast.co.za';
// Posted variables from ITN
$pfData = $_POST;

//update db
switch( $pfData['payment_status'] )
{
 case 'COMPLETE':
 $directory = $cart_database_path."sales/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}
$transid = $pfData['m_payment_id'];
$sales = $directory.$transid.".json";
$salesByCode = json_decode(file_get_contents($sales), true);
if($pfData['amount_gross'] == $salesByCode["amount"]){
$thisSales = array('code'=>$transid, 'amount'=>$salesByCode["amount"], 'status'=>"Paid", 'day'=>$salesByCode["day"],'pro'=>$salesByCode["pro"],'pcode'=>$salesByCode["pcode"],'cname'=>$salesByCode["cname"], 'phone'=>$salesByCode["phone"], 'email'=>$salesByCode["email"], 'add'=>$salesByCode["add"]);
$thisSales = json_encode($thisSales);
file_put_contents($directory.$transid.".json",$thisSales);
$dtnow = @date('d/m/Y h:i:s A');
$trackinfo = "<hr><p><b>".$dtnow." :&nbsp;</b>A Payment  of ".@$salesByCode['pcode'].number_format($pfData['amount_gross'], 2)." was recieved Via Our  ".@$salesByCode["pro"]." payment processor Terminal and the Status of the payment is ".$pfData['payment_status']."</p><hr>";
file_put_contents($cart_database_path."track/".$transid.".txt", $trackinfo, FILE_APPEND);
$order	=  json_decode(file_get_contents($cart_database_path."orders/".$transid.".json"), true);
foreach ($order as $item){
$product	=  json_decode(file_get_contents($cart_database_path."products/".$item['code'].".json"), true);	
if($product["digital-d"] != "")
{
$dtnow = @date('d/m/Y h:i:s A');
$trackinfo = "<hr><p><b>".$dtnow." :&nbsp;</b>".$product["pname"]." Was enabled for you to download. <a target='_blank' href='".$product['digital-d']."'>Click Here to start downloading</a>.</p><hr>";
file_put_contents($cart_database_path."track/".$transid.".txt", $trackinfo, FILE_APPEND);	
}
}
exit;
}
 break;
 case 'FAILED':                    
    exit;
 break;
 default:
    exit;
 break;
}
exit;

?>
