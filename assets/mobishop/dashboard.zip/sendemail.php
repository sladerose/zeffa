<?php
$dtnow = @date('d/m/Y h:i:s A');
$amt = $_POST["total_amount"] + $_POST["vat"] + $_POST["shipping"];
$trackinfo = "<hr><p><b>".$dtnow." :&nbsp;</b> You Made An Order of ".@$_POST["proicon"].number_format($amt, 2)."</b> With Transaction ID : <b>".$transid."</b> Using ".@$_POST["pro"]." payment processor Terminal.<br><br></p><hr>";
file_put_contents($directory4.$transid.".txt", $trackinfo, FILE_APPEND);
$mailto = $_POST['email'];
$subject = 'You Order Confirmation';
$subject2 = 'A New Order have been placed';
$message = 'Dear '. @$name[0]." ".@$name[1].', Your Order on www.'.@$_SERVER['HTTP_HOST'].' Have been recieved. You can track the progress of this order using it transaction id : ';
$message .= $transid.'\r\n\r\n Thanks for your patronage';
$message2 = 'A new Order have been placed on your website:  www.'.@$_SERVER['HTTP_HOST'].' You can track the order using it transaction id : ';
$message2 .= $transid;
$header  = "From: no_reply@".@$_SERVER['HTTP_HOST']."\r\n";
$header .= "Reply-To: no_reply@".@$_SERVER['HTTP_HOST']."\r\n";
$header .= "MIME-Version: 1.0"."\r\n";
$header .= "Content-Type: text/plain; charset=utf-8"."\r\n";
$header .= "Content-Transfer-Encoding: 8bit"."\r\n";
$header .= "X-Mailer: PHP v".phpversion();
if($settings["cemail"] == "Yes"){
mail($mailto, $subject, $message, $header);
}
if($settings["semail"] == "Yes"){
mail($email, $subject2, $message2, $header);
}
if($settings["ssms"] == "Yes"){
include "../../sendsms.php";
}
?>