<?php
include "./setup.php";
$settings	=  json_decode(@file_get_contents($cart_database_path."settings/data.json"), true);
$sales	=  json_decode(@file_get_contents($cart_database_path."sales/".$_GET["orderid"].".json"), true);
if(empty($sales["email"])){
echo "No Information Matched your Track ID";
exit();	
}
$track	=  file_get_contents($cart_database_path."/track/".$_GET["orderid"].".txt");
?>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Tracking rder</title>
<link href="css/invoice.css?v=01" type="text/css" rel="stylesheet" />
</head>
<body>	
<div id="shopping-cart">
<div style="text-align: right; font-size:18px">Status: <?php echo "<span style='color: red;'>".$sales["status"]."</span>";?><br><br></div>
<table class="table" cellpadding="3" cellspacing="1" width="100%">	
<thead class="bg-primary">
<tr>
<th style="text-align:left; width: 50%">Name:</th>
<th style="text-align:left;">Phone:</th>
</tr>
<thead>
<tbody>
<tr>
<td><?php echo htmlspecialchars($sales["cname"]);?></td>
<td><?php echo htmlspecialchars($sales["phone"]);?></td>
</tr>
</tbody>
</table> 
<table cellpadding="3" cellspacing="1" width="100%" class="table" >	
<thead class="bg-primary">
<tr>
<th style="text-align:left; width: 50%">Email:</th>
<th style="text-align:left;">Address:</th>
</tr>
<thead>
<tbody>
<tr>
<td><?php echo htmlspecialchars($sales["email"]);?></td>
<td><?php echo htmlspecialchars($sales["add"]);?></td>
</tr>
</tbody>
</table> 
<div class="container"><?php echo $track;?></div>


</div>

  <script>
$(document).on('click', '.print-in', function() {
   w=window.open();
w.document.write($('#shopping-cart').html());
w.print();
w.close();
  });

</script>
</body>
</html>

