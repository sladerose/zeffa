<?php
session_start();
require_once("../../setup.php");
//You Cant Access Page Direct.
if(empty($_POST)){
header("Location: ../../");
exit();
}
$settings	=  json_decode(file_get_contents($payment_processor_database_path."settings/data.json"), true);
$info = json_encode($_POST);
$name = @$_POST["name"];
$name = explode(" ", $name);
require_once("./saveorder.php");
$transact_id = $transid;
?>
<!DOCTYPE html>
 <html>
 <head>
<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>Payment On Delivery Processing Gateway</title>
  <style>
  #overlay {
  position: fixed;
  display: none;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 2;
  cursor: pointer;
}

#overlaytext {
  position: absolute;
  background-color: #673ab7;
  top: 50%;
  left: 50%;
  color: #fff;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
}
.text{
padding-top: 10px;
padding-bottom: 10px;
font-size: 20px;
text-align: center;
}
  </style>
</head>
<body>
<div id="overlay" onclick="off()">
  <div id="overlaytext"><img src="../../images/pnd.gif" style="max-height: 400px" height="auto"><br><div class="text">Your order have been recieved<br></div></div>
</div>
 <script>
function overlayon() {
  document.getElementById("overlay").style.display = "block";
}

function overlayoff() {
  document.getElementById("overlay").style.display = "none";
}
overlayon();
</script> 
</body>
</html>