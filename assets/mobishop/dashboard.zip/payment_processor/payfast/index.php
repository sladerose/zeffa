<?php
session_start();
require_once("../../setup.php");
//You Cant Access Page Direct.
if(empty($_POST)){
header("Location: ../../../");
}
$settings	=  json_decode(file_get_contents($payment_processor_database_path."settings/data.json"), true);
$info = json_encode($_POST);
$name = @$_POST["name"];
$name = explode(" ", $name);
require_once("./saveorder.php");
$transact_id = $transid;
//Payfast server url
$payfast_url = $payfast_url;
//Payfast Marchant ID
$payfast_mid = $payfast_mid;
//Payfast Marchant Key
$payfast_key = $payfast_key;
//Payfast return url
$payfast_return_url = $payfast_return_url;
//Payfast cancel url
$payfast_cancel_url = $payfast_cancel_url;
//Payfast itn url
$payfast_notify_url = $payfast_notify_url;
//Payfast Notification email
$payfast_notify_email = $payfast_notify_email;
//Paying for
$paying_for = htmlspecialchars(trim($_POST["name"]))." purchased product(s)";
//Paying for
$payment_desc = "Transaction ID of the purchased is : ".$transact_id;
 ?>
<!DOCTYPE html>
 <html>
 <head>
  <meta charset="UTF-8">
  <title>PayFast Payment Processing Gateway</title>
</head>
 <body>
<form action="<?php echo @$payfast_url;?>" method="POST" id="jsform">
<input type="hidden" name="merchant_id" value="<?php echo @$payfast_mid;?>">
<input type="hidden" name="merchant_key" value="<?php echo @$payfast_key;?>">
<input type="hidden" name="return_url" value="<?php echo @$payfast_return_url;?>">
<input type="hidden" name="cancel_url" value="<?php echo @$payfast_cancel_url;?>">
<?php
if($settings["protype"] == "Automatic"){
?>
<input type="hidden" name="notify_url" value="<?php echo $payfast_notify_url;?>">
<?php
}
?>

<input type="hidden" name="name_first" value="<?php echo @$name[0];?>">
<input type="hidden" name="name_last" value="<?php echo @$name[1];?>">
<input type="hidden" name="email_address" value="<?php echo @$_POST["email"];?>">
<input type="hidden" name="cell_number" value="<?php echo @$_POST["phone"];?>">


<input type="hidden" name="m_payment_id" value="<?php echo @$transact_id;?>">
<input type="hidden" name="amount" value="<?php echo @$_POST["total_amount"]+$_POST["vat"]+$_POST["shipping"];?>">
<input type="hidden" name="item_name" value="<?php echo @$paying_for;?>">
<input type="hidden" name="item_description" value="<?php echo @$payment_desc;?>">

<input type="hidden" name="email_confirmation" value="1">
<input type="hidden" name="confirmation_address" value="<?php echo @$payfast_notify_email;?>">
<div style="display: none">
<input type="image" src="https://www.payfast.co.za/images/buttons/light-small-paynow.png" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
</div>
</form>
<script type="text/javascript">
  document.getElementById('jsform').submit();
</script>
</body>
</html>