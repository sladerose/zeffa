<?php
session_start();
require_once("../../setup.php");
//You Cant Access Page Direct.
if(empty($_POST)){
header("Location: ../../");
exit();
}
$settings	=  json_decode(file_get_contents($payment_processor_database_path."settings/data.json"), true);
$info = json_encode($_POST);
$name = @$_POST["name"];
$name = explode(" ", $name);
require_once("./saveorder.php");
$transact_id = $transid;
//PayPal server url
$paypal_url = $paypal_url;
//PayPal currency code
$paypal_currency_code = $paypal_currency_code;
//Paypal success url
$paypal_success_url = $paypal_success_url;
//Paypal cancel url
$paypal_cancel_url = $paypal_cancel_url;
//Paypal itn url
$paypal_notify_url = $paypal_notify_url;
//Paypal Account email
$paypal_account_email = $paypal_account_email;
//Paying for
$paying_for = htmlspecialchars(trim($_POST["name"]))." purchased product(s)";
//Paying for
$payment_desc = "Transaction ID of the purchased is : ".$transact_id;;
 ?>
<!DOCTYPE html>
 <head>
  <meta charset="UTF-8">
  <title>Paypal Payment Processing Gateway</title>
</head>
 <body>
<form action="<?php echo $paypal_url;?>" method="POST" id="jsform">
 <div class="cart_pinfo"></div>
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="item_name" value="<?php echo $paying_for;?>">
<input type="hidden" name="item_number" value="<?php echo @$payment_desc;?>">
<input type="hidden" name="custom" value="<?php echo @$transid;?>"/>
<input type="hidden" name="amount" value="<?php echo $amt;?>">	
<input type="hidden" name="first_name" value="<?php echo @$name[0];?>" />
<input type="hidden" name="last_name" value="<?php echo @$name[1];?>" />
<input type="hidden" name="business" value="<?php echo $paypal_account_email;?>">
<input type="hidden" name="currency_code" value="<?php echo $settings["pcode"];?>">
<?php
if($settings["protype"] == "Automatic"){
?>
<input type="hidden" name="notify_url" value="<?php echo $paypal_notify_url;?>">
<?php
}
?>
<input type="hidden" name="return" value="<?php echo $paypal_success_url;?>">
<input type="hidden" name="cancel_return" value="<?php echo $paypal_cancel_url;?>">
<input value="1" name="no_note" type="hidden">
<input type="hidden" name="rm" value="2">
<input type="hidden" name="cbt" value="Return to The Store">
</form>
<script type="text/javascript">
document.getElementById('jsform').submit();
</script>
</body>
</html>