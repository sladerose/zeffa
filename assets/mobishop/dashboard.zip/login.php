<?php
session_start();
require_once("./setup.php");
if(!empty($_POST["email"]) && !empty($_POST["password"])){
if($_POST["email"] == $email && $_POST["password"] == $pass){
$_SESSION["loggedin"] = $_POST["email"];
$_SESSION["theme"] = $theme;
header('Location: ./dashboard/');
exit;
}else{
$error	= "<div class='bg-danger text-white p-3'>Invalid Login Information</div>";	
}	
	
}


?>
<!doctype html>
<html>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>MobiShop - Dashboard Login</title>
<link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css' rel='stylesheet'>
<link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>
<style>body {
    background-color: #eee;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh
}

.card {
    width: 400px;
    padding: 20px;
    border: none
}

.account {
    font-weight: 500;
    font-size: 17px
}

.contact {
    font-size: 13px
}

.form-control {
    text-indent: 14px
}

.form-control:focus {
    color: #495057;
    background-color: #fff;
    border-color: #4a148c;
    outline: 0;
    box-shadow: none
}

.inputbox {
    margin-bottom: 10px;
    position: relative
}

.inputbox i {
    position: absolute;
    left: 8px;
    top: 12px;
    color: #dadada
}

.form-check-label {
    font-size: 13px
}

.form-check-input {
    width: 14px;
    height: 15px;
    margin-top: 5px
}

.forgot {
    font-size: 14px;
    text-decoration: none;
    color: #4A148C
}

.mail {
    color: #4a148c;
    text-decoration: none
}

.form-check {
    cursor: pointer
}

.btn-primary {
    color: #fff;
    background-color: <?php echo $theme;?>;
    border-color: <?php echo $theme;?>
}</style>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
<script type='text/javascript' src='https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js'></script>
<script type='text/javascript'></script>
</head>
<body oncontextmenu='return false' class='snippet-body'>
                            <form class="card" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <div class="text-center intro"> <img src="dashboard/images/logo.png" width="160"> </div>
    <div class="mt-4 text-center">
        <h4>Log In.</h4> <span>Login with your admin credentials</span>
        <div class="mt-3 inputbox"> <input type="text" class="form-control" name="email" placeholder="Email" value="<?php echo @$_POST["email"]; ?>"> <i class="fa fa-envelope"></i> </div>
        <div class="inputbox"> <input type="password" class="form-control" name="password" placeholder="Password"> <i class="fa fa-lock"></i> </div>
		<?php echo @$error;?>
    </div>
    <div class="d-flex justify-content-between">
        <div class="form-check"> <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"> <label class="form-check-label" for="flexCheckDefault"> Keep me Logged in </label> </div>
        
    </div>
    <div class="mt-2 mb-5"> <button class="btn btn-primary btn-block" type="submit" >Log In</button> </div>
</form>
</body>
</html>