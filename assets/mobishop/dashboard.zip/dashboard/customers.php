<?php
include "include/config.php";	
?>
<div class="border-bottom mb-3 row">
<div class="col text-center"><h4><b>Customers</b></h4></div>
</div>
    <table id="datatable4" class="table  table-striped table-bordered dt-responsive nowrap display" cellspacing="0" width="100%">
    				<thead>
						<tr>
							<th width="40%">Customer's Name</th>
							<th width="30%">Email</th>
							<th width="30%">Phone Number</th>
							<th class="none">Address</th>
							<th class="none">Action</th>
                        </tr>
					</thead>
					
</table>
<script>
$.fn.dataTable.ext.errMode = 'none';
   var table4 =  $('#datatable4').DataTable({ 
	  "ajax":{
        "url":"./customerlist.php?rnd=" + String((new Date()).getTime()).replace(/\D/gi, ''),
 "contentType":"application/json; charset=utf-8",
      "dataType":"json",
        "dataSrc": function ( json ) { 
		var valuesparent = $.map( json, function (value, key) { return value; });
        return valuesparent;
		  },
	"error": function (error) { 
		  }, 
      },
        "columns": [
		{ "data": "cname" ,"defaultContent": "Not set"  },
		{ "data": "email" ,"defaultContent": "Not set"  },
			{ "data": "phone" ,"defaultContent": "Not set"  },
			{ "data": "add" ,"defaultContent": "Not set"  },
			{ "data": "code" ,"defaultContent": "Not set"  },
        ],
		"columnDefs": [ {
    "targets": 4,
    "data": "download_link",
    "render": function ( data, type, row, meta ) {
	  return '<a class="btn dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b><i class="fa fa-indent"></i></b></a><div class="dropdown-menu" aria-labelledby="navbarDropdown"><a class="dropdown-item sendmessage btn-sm" href="#" title="Send Message"><i class="fa fa-envelope"></i>&nbsp;&nbsp;Send Message</a>';

	}
  }],
		deferRender: true,
		responsive: true,
		"autoWidth": false,
		dom: 'Bfrtip',
        buttons: [
        'pdf',
        'excel',
        'print'
    ]
		
  });
	$('#datatable4 tbody').on('click', '.sendmessage', function (element) {
var tr = $(element.target).closest('tr');
        if(tr.hasClass('child'))
        {
            tr=$(tr).prev();
        }
        var datat = table4.row(tr).data();
		$(".pagecontent").empty();
		 $("#loader").show();
$(".pagecontent").load("./sendmessage2.php",function(){
		$("#email").val(datat["email"]);
		$("#rname").val(datat["cname"]);
		$(".all").hide();
		$(".pagecontent").show();
		$(".loader").hide();
    } );
    } );
	
</script>