<?php
require_once("../config.php");
$payment_api	= file_get_contents("../payment_processor/list.json");
$directory = $dashbard_database_path."settings/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}
$datainfo	= json_decode(file_get_contents($directory."data.json"), true);
if(!empty($_POST)){	

$msg = "Settings Updated Successfully";
$submitdata = array("pcode" => @$_POST["pcode"],"picon" => @$_POST["picon"],"msc" => @$_POST["msc"],"fsa" => @$_POST["fsa"],"ptax" => @$_POST["ptax"],"papi" => @$_POST["papi"],"cemail" => @$_POST["cemail"],"semail" => @$_POST["semail"],"nemail" => @$_POST["nemail"],"ssms" => @$_POST["ssms"],"protype" => @$_POST["protype"],"smsurl" =>  @$_POST["smsurl"],"smsvnm" => @$_POST["smsvnm"],"smsuvan" => @$_POST["smsuvan"],"smsuvn" => @$_POST["smsuvn"],"smspvan" => @$_POST["smspvan"],"smspvn" => @$_POST["smspvn"],"smssivan" => @$_POST["smssivan"],"smssivn" => @$_POST["smssivn"],"smstelevan" => @$_POST["smstelevan"],"smstelevn" => @$_POST["smstelevn"],"smsencode" => @$_POST["smsencode"],"custom1" =>  "","custom2" =>  "","custom3" =>  "");
$encode_data = json_encode($submitdata);
file_put_contents($directory."data.json", $encode_data);
$cc = json_encode(array("status" => "Success","code" => "200","message" => $msg,"rtype" => "settings"));
echo $cc;
exit;
}
?>
<div class="border-bottom mb-3 row">
<div class="col"><h4><span class="btn btn-primary" onClick="$('.all').hide();$('.products').show();"><i class="fa fa-angle-left"></i>&nbsp;&nbsp;Back</span></h4></div>
<div class="col text-center"><h4><b>Settings</b></h4></div>
<div class="col text-right"></div>
</div>
    <form class="modal-content" method="post" id="setting_form">
          <div class="modal-body">
		  <div class="text-center border-bottom mb-4"><strong>Shopping Cart Configuration</strong></div>
		  <div class="form-group">
        <select class="form-control " name="cicon" id="cicon" placeholder="Currency Icon" data-validation="required" data-validation-error-msg="Choose Currency Icon">
		<option value="">Currency Icon</option>
        <option value="$"<?php echo ($datainfo["picon"] == "$" ? "selected" : '');?>>USD</option>
        <option value="€"<?php echo ($datainfo["picon"] == "€" ? "selected" : '');?>>EUR</option>
		<option value="£"<?php echo ($datainfo["picon"] == "£" ? "selected" : '');?>>GBP</option>
		<option value="₦"<?php echo ($datainfo["picon"] == "₦" ? "selected" : '');?>>NGN</option>
		<option value="R"<?php echo ($datainfo["picon"] == "R" ? "selected" : '');?>>ZAR</option>
        </select>
		<input class="form-control" name="picon" id="picon" type="hidden" value="<?php echo @$datainfo["picon"];?>">
		<input class="form-control" name="pcode" id="pcode" type="hidden" value="<?php echo @$datainfo["pcode"];?>">
        </div>
		<div class="form-group">
        <input class="form-control" id="msc" name="msc" type="text" placeholder="Max Shipping Charge, example: 20.00" data-validation="custom" data-validation-regexp="^([0-9.]+)$" data-validation-error-msg="Provide a numeric value" value="<?php echo @$datainfo["msc"];?>">
        </div>
		<div class="form-group">
        <input class="form-control" id="fsa" name="fsa" type="text" placeholder="Free Shipping at, example: 20.00" data-validation="custom" data-validation-regexp="^([0-9.]+)$" data-validation-error-msg="Provide a numeric value" value="<?php echo @$datainfo["fsa"];?>">
        </div>
		<div class="form-group">
        <select class="form-control " name="ptax" id="ptax" placeholder="Vat Configuration" data-validation="required" data-validation-error-msg="Select Vat Configuration">
		<option value="">Vat Configuration</option>
		<option value="No.vat"<?php echo ($datainfo["ptax"] == "No.vat" ? "selected" : '');?>>No vat on my products</option>
        <option value="In.vat"<?php echo ($datainfo["ptax"] == "In.vat" ? "selected" : '');?>>Include vat on cart total</option>
        <option value="Ex.vat"<?php echo ($datainfo["ptax"] == "Ex.vat" ? "selected" : '');?>>Exclude vat on cart total</option>
        </select>
        </div>
		<div class="text-center border-bottom mb-4"><strong>Payment Configuration</strong></div>
		<div class="form-group">
        <select class="form-control " name="protype" id="protype" placeholder="Payment Processing Type" data-validation="required" data-validation-error-msg="Payment Processing Type">
		<option value="">Payment Processing Type</option>
		<option value="Automatic"<?php echo ($datainfo["protype"] == "Automatic" ? "selected" : '');?>>Automatic payment processing</option>
        <option value="Manual"<?php echo ($datainfo["protype"] == "Manual" ? "selected" : '');?>>Manual payment processing</option>
        </select>
        </div>
		<div class="form-group">
        <select class="form-control"  name="papi" id="papi" data-validation="required" data-validation-error-msg="Choose a Payment Processor">
		<option value="">Payment Processor</option>
		<?php 
		$payment_api = json_decode($payment_api, true);
		foreach($payment_api as $item)
{
		?>
        <option value="<?php echo $item["name"];?>"<?php echo ($datainfo["papi"] == $item["name"] ? "selected" : '');?>><?php echo $item["name"] ." payment processor";?></option>
		<?php
		}
		?>
        </select>
        </div>
		<div class="text-center border-bottom mb-4"><strong>Notification Configuration</strong></div>
		<div class="form-group">
        <select class="form-control " name="cemail" id="cemail" placeholder="Enable/Disable Email Notification to customer" data-validation="required" data-validation-error-msg="Choose one option">
		<option value="">Enable/Disable Email Notification to customer</option>
		<option value="Yes"<?php echo ($datainfo["cemail"] == "Yes" ? "selected" : '');?>>Yes Send Order Email Notification to customer</option>
        <option value="No"<?php echo ($datainfo["cemail"] == "No" ? "selected" : '');?>>Dont Send Order Email Notification to customer</option>
        </select>
        </div>
		<div class="form-group">
        <select class="form-control " name="semail" id="semail" placeholder="Enable/Disable Email Notification to me" data-validation="required" data-validation-error-msg="Choose one option">
		<option value="">Enable/Disable Email Notification to me</option>
		<option value="Yes"<?php echo ($datainfo["semail"] == "Yes" ? "selected" : '');?>>Yes Send Order Email Notification to me</option>
        <option value="No"<?php echo ($datainfo["semail"] == "No" ? "selected" : '');?>>Dont Send Order Email Notification to me</option>
        </select>
        </div>
		<div class="form-group nemail" style="display: <?php echo ($datainfo["semail"] == "Yes" ? "block" : 'none');?>">
        <input class="form-control" id="nemail" name="nemail" type="email" placeholder="Email Address were you will receive notification" data-validation="email"  data-validation-error-msg="Provide a valid email address" value="<?php echo @$datainfo["nemail"];?>">
        </div>
		<div class="form-group">
        <select class="form-control " name="ssms" id="ssms" placeholder="Enable/Disable Order SMS Notification to me" data-validation="required" data-validation-error-msg="Choose one option">
		<option value="">Enable/Disable Order SMS Notification to me</option>
		<option value="Yes"<?php echo ($datainfo["ssms"] == "Yes" ? "selected" : '');?>>Yes Send Order SMS Notification to me</option>
        <option value="No"<?php echo ($datainfo["ssms"] == "No" ? "selected" : '');?>>Dont Send Order SMS Notification to me</option>
        </select>
        </div>
		<div  class="smsconf row" style="display: <?php echo ($datainfo["ssms"] == "Yes" ? "block" : 'none');?>">
		<div class="form-group col-md-6">
        <input class="form-control" id="smsurl" name="smsurl" type="text" placeholder="Your BulkSMS Api Url" data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api Url" value="<?php echo @$datainfo["smsurl"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smsvnm" name="smsvnm" type="text" placeholder="Your BulkSMS Api variable name for Message" data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api variable name for Message" value="<?php echo @$datainfo["smsvnm"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smsuvan" name="smsuvan" type="text" placeholder="Your BulkSMS Api variable name for Username " data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api variable name for Username" value="<?php echo @$datainfo["smsuvan"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smsuvn" name="smsuvn" type="text" placeholder="Your BulkSMS Api value for Username " data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api value  for Username" value="<?php echo @$datainfo["smsuvn"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smspvan" name="smspvan" type="text" placeholder="Your BulkSMS Api variable name for Password " data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api variable name for Password" value="<?php echo @$datainfo["smspvan"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smspvn" name="smspvn" type="text" placeholder="Your BulkSMS Api value for Password " data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api value  for Password" value="<?php echo @$datainfo["smspvn"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smssivan" name="smssivan" type="text" placeholder="Your BulkSMS Api variable name for Sender ID" data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api variable name for Sender ID" value="<?php echo @$datainfo["smssivan"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smssivn" name="smssivn" type="text" placeholder="Your BulkSMS Api value for  Sender ID " data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api value  for  Sender ID" value="<?php echo @$datainfo["smssivn"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smstelevan" name="smstelevan" type="text" placeholder="Your BulkSMS Api variable name for Receiver Phone No." data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api variable name for Receiver Phone No" value="<?php echo @$datainfo["smstelevan"];?>">
        </div>
		<div class="form-group col-md-6">
        <input class="form-control" id="smstelevn" name="smstelevn" type="text" placeholder="Your BulkSMS Api value for Receiver Phone No " data-validation="required"  data-validation-error-msg="Provide Your BulkSMS Api value for Receiver Phone No" value="<?php echo @$datainfo["smstelevn"];?>">
        </div>
		<div class="form-group col-md-12">
        <select class="form-control " name="smsencode" id="smsencode" placeholder="Encode SMS Data before sending it to BulkSMS Api" data-validation="required" data-validation-error-msg="Choose one option">
		<option value="">Encode SMS Data before sending it to BulkSMS Api</option>
		<option value="Yes"<?php echo ($datainfo["smsencode"] == "Yes" ? "selected" : '');?>>Yes Encode SMS Data</option>
        <option value="No"<?php echo ($datainfo["smsencode"] == "No" ? "selected" : '');?>>Dont  Encode SMS Data</option>
        </select>
        </div>
		</div>
      </div>
          <div class="modal-footer ">
      <button type="submit" class="btn btn-primary" ><span class="fa fa-paper-plane"></span>&nbsp;&nbsp;Process</button>
      </div>
        </form>
        
   <script>
$.validate({
    form : '#setting_form',
    modules : 'security',
	onError : function($form) {
		$("#snackbar").html("Form Validation Failed");
myswagFunction();
	  return false; // Will stop the submission of the form
    },
    onSuccess : function($form) {
	if($form.attr('id') == "setting_form")
	{
	$(".pagecontent").hide();
	$(".loader").show();
	Processclass()	
	}
    return false; // Will stop the submission of the form
    },
  });
function Processclass()
   {
var ur1 = "settings.php";
var method = "POST";
$.ajax({
    type: method,
    url: ur1,
    data:  $('#setting_form').serialize() + "&form_name=mclass&rnd=" + String((new Date()).getTime()).replace(/\D/gi, ''), // access in body
}).done(function (data) {
data = JSON.parse(data);
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html(data.message);
myswagFunction();
}).fail(function (error) {
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html("Request Not Processed");
myswagFunction();
}).always(function (cdata) {
});
     
    
   }  
$(document).on("change", "#semail", function(event)
{	
if($(this).find("option:selected").val() == "Yes"){
$(".nemail").show();	
}else{
$(".nemail").hide();	
}
});  
 $(document).on("change", "#ssms", function(event)
{	
if($(this).find("option:selected").val() == "Yes"){
$(".smsconf").show();	
}else{
$(".smsconf").hide();	
}
}); 
$(document).on("change", "#cicon", function(event)
{
$("#picode").val($(this).find("option:selected").text());
$("#picon").val($(this).find("option:selected").val());
});
</script>