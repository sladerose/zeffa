<?php
include "../config.php";
if(!empty($_POST)){	
$directory = $dashbard_database_path."products/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}

$date = date("d/m/Y");	
$proid = $_POST["pcode"];
$msg = "Action Completed Successfully";
$submitdata = array("code" => $proid,"pname" => htmlspecialchars(@$_POST["pname"]),"price" => htmlspecialchars(@$_POST["pprice"]),"pstatus" => htmlspecialchars(@$_POST["pstatus"]),"pstock" => htmlspecialchars(@$_POST["pstock"]),"ptax" => htmlspecialchars(@$_POST["ptax"]),"pshipping" =>  htmlspecialchars(@$_POST["pshipping"]),"description" => htmlspecialchars(@$_POST["description"]),"pdate" => $date,"digit-d" => $_POST["digit-d"],"custom1" => "","custom2" => "","custom2" => "");

$encode_data = json_encode($submitdata);
file_put_contents($directory.$proid.".json", $encode_data);
$cc = json_encode(array("status" => "Success","code" => "200","message" => $msg,"rtype" => "mproduct"));
echo $cc;
exit;
}
?>
<div class="border-bottom mb-3 row">
<div class="col"><h4><span class="btn btn-primary" onClick="$('.all').hide();$('.products').show();"><i class="fa fa-angle-left"></i>&nbsp;&nbsp;Back</span></h4></div>
<div class="col text-center"><h4><b>&nbsp;&nbsp;Manage Product</b></h4></div>
<div class="col text-right"></div>
</div>
    <form class="modal-content" method="post" id="product_form">
          <div class="modal-body">
		  <div class="form-group">
        <input class="form-control" id="pcode" name="pcode" type="text" placeholder="Product ID : Alphanumeric characters" data-validation="custom" data-validation-regexp="^([A-Za-z0-9]+)$" data-validation-error-msg="Provide a valid Product ID">
        </div>
		  <div class="form-group">
          <input class="form-control" name="pname" id="pname" type="text" placeholder="Product Name" data-validation="required" data-validation-error-msg="Provide a product name Please">
        </div>
		<div class="form-group">
        <input class="form-control" id="pprice" name="pprice" type="text" placeholder="Product Price" data-validation="custom" data-validation-regexp="^([0-9.]+)$" data-validation-error-msg="Provide a valid Product Price">
        </div>
		<div class="form-group">
        <select class="form-control " name="pstatus" id="pstatus" placeholder="Choose Status" data-validation="required" data-validation-error-msg="Choose Product Status">
		<option value="">Product Availability</option>
        <option value="Available">Avaliable</option>
        <option value="Not Available">Not Available</option>
        </select>
        </div>
		<div class="form-group">
        <input class="form-control" id="pstock" name="pstock" type="text" placeholder="Product Remaining in stock" data-validation="custom" data-validation-regexp="^([0-9.]+)$" data-validation-error-msg="Provide a valid Remaining Stock">
        </div>
		<div class="form-group">
        <input class="form-control" id="ptax" name="ptax" type="text" placeholder="Product Tax/Vat amount" data-validation="custom" data-validation-regexp="^([0-9.]+)$" data-validation-error-msg="Provide a valid tax/vat" value="0.00">
        </div>
<div class="form-group">
        <input class="form-control" id="pshipping" name="pshipping" type="text" placeholder="Product Shpping amount" data-validation="custom" data-validation-regexp="^([0-9.]+)$" data-validation-error-msg="Provide a valid shipping amount" value="0.00">
        </div>
		<div class="form-group">
        <input class="form-control" id="digit-d" name="digit-d" type="text" placeholder="Digital file Download Url">
        </div>
		<div class="form-group">
		<textarea class="form-control" id="description" name="description" placeholder="Product description" data-validation="required" data-validation-error-msg="Product description is Needed"></textarea>
        </div>	
      </div>
          <div class="modal-footer ">
      <button type="submit" class="btn btn-primary" ><span class="fa fa-paper-plane"></span>&nbsp;&nbsp;Process</button>
      </div>
        </form>
        
   <script>
$.validate({
    form : '#product_form',
    modules : 'security',
	onError : function($form) {
		$("#snackbar").html("Form Validation Failed");
myswagFunction();
	  return false; // Will stop the submission of the form
    },
    onSuccess : function($form) {
	if($form.attr('id') == "product_form")
	{
	$(".pagecontent").hide();
	$(".loader").show();
	Processclass()	
	}
    return false; // Will stop the submission of the form
    },
  });
function Processclass()
   {
var ur1 = "mproduct.php";
var method = "POST";
$.ajax({
    type: method,
    url: ur1,
    data:  $('#product_form').serialize() + "&form_name=mclass&rnd=" + String((new Date()).getTime()).replace(/\D/gi, ''), // access in body
}).done(function (data) {
data = JSON.parse(data);
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html(data.message);
myswagFunction();
}).fail(function (error) {
$(".loader").hide();
$(".pagecontent").show();
$("#snackbar").html("Request Not Processed");
myswagFunction();
}).always(function (cdata) {
});
     
    
   }  
$(document).on("change", "#cclcodev", function(event)
{
$("#clname").val($(this).find("option:selected").text());
$("#clcode").val($(this).find("option:selected").val());
});   
</script>