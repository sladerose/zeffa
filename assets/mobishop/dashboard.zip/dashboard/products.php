<?php
include "../config.php";	
?>
<div class="border-bottom mb-3 row">
<div class="col"></div>
<div class="col text-center"><h4><b>Products</b></h4></div>
<div class="col text-right"><h4><a href="#" id="mproduct.php" class="newlink btn btn-primary"><i class="fa fa-plus"></i>&nbsp;&nbsp;New Product</a></h4></div>
</div>
	
     <table id="datatable1" class="table  table-striped table-bordered dt-responsive nowrap display" cellspacing="0" width="100%">
    				<thead>
						<tr>
							<th width="40%">Product Name</th>
							<th width="30%">ID Number</th>
							<th width="30%">Price</th>
							<th class="none">Added Date</th>
							<th class="none">Tax</th>
							<th class="none">Shipping</th>
							<th class="none">Availability</th>
							<th class="none">Remain in Stock</th>
							<th class="none">About</th>
							<th class="none">Action</th>
                        </tr>
					</thead>
					
				</table>