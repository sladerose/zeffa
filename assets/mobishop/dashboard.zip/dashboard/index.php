<?php
session_start();
error_reporting(0);
$theme = $_SESSION["theme"];
if(!isset($_SESSION["loggedin"])){
header('Location: ../');
exit;	
}
if (isset($_GET["action"]) && $_GET["action"] == 'logout')
      {
         session_unset();
         session_destroy();
         header('Location: ../');
         exit;
      }
	 
   

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Welcome to Mobishop v1.03 Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<meta name="theme-color" content="#fff" />
<link rel="stylesheet" type="text/css" href="css/pagestyle.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4-4.1.1/jq-3.3.1/jszip-2.5.0/dt-1.10.21/b-1.6.3/b-html5-1.6.3/b-print-1.6.3/r-2.2.5/sp-1.1.1/sl-1.3.1/datatables.min.css"/>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4-4.1.1/jq-3.3.1/jszip-2.5.0/dt-1.10.21/b-1.6.3/b-html5-1.6.3/b-print-1.6.3/r-2.2.5/sp-1.1.1/sl-1.3.1/datatables.min.js"></script> 
<script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>


    <style type="text/css">

.bg-primary {
    background-color: <?php echo $theme;?> !important;
	color:#fff;
}
.btn-primary {
    background-color: <?php echo $theme;?> !important;
	border-color: <?php echo $theme;?>;
	color:#fff;
}
.btn-group > .btn {
    background-color: <?php echo $theme;?> !important;
	border-color: <?php echo $theme;?>;
	color:#fff;
}
.nav-link {
	color:#fff;
}
.dtr-control:before {
	background-color: <?php echo $theme;?> !important;
	color:#fff;
}
.page-item.active .page-link{
	background-color: <?php echo $theme;?> !important;
	border-color: <?php echo $theme;?>;
	color:#fff;
}
.fill-box {
    position: relative;
    background: <?php echo $theme;?>;
    border: 0.25rem solid <?php echo $theme;?>;
    height: 8rem;
    width: 8rem;
    outline: 0;
    overflow: hidden
}



    </style>
	
	
</head>
<body>
<div class="text-center pt-2">
<a class="navbar-brand" href="#"><img style="width: 80px;" src="./images/logo.png" alt="LOGO"><br><b>Mobishop Dashboard</b></a>
</div>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
<div class="container-fluid">
                <a class="navbar-brand" href="#">Dashboard</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
                    <ul class="nav navbar-nav  nav-dropdown ml-auto" data-app-modern-menu="true">
					<li class="nav-item active"><a class="nav-link text-white" href="#"  onClick="$('.all').hide();$('.products').show();"><i class="fa fa-list"></i>&nbsp;&nbsp;<b>Products List</b></a></li>
		   <li class="nav-item"><a class="nav-link text-white" href="#"   onClick="$('.all').hide();$('.customers').show();"><i class="fa fa-users"></i>&nbsp;&nbsp;<b>Customers List</b></a></li>
		   <li class="nav-item"><a class="nav-link text-white" href="#"   onClick="$('.all').hide();$('.sales').show();"><i class="fa fa-shopping-cart"></i>&nbsp;&nbsp;<b>Sales List</b></a></li>
		      <li class="nav-item"><a class="nav-link text-white newlink" id="./settings.php" href="#"><i class="fa fa-cogs"></i>&nbsp;&nbsp;<b>Settings</b></a></li>
					
					</ul>
					<ul class="navbar-nav ml-auto nav-dropdown" data-app-modern-menu="true">
					<li class="nav-item dropdown active">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <b>Account</b>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item"  href="?action=logout"><i class="fa fa-power-off"></i>&nbsp;&nbsp;Logout</a>
      </li>
					</ul>
                </div>
				</div>

            </nav>
			
 

<div class="loader wrapper" style=" display: none">
    <div class="fill-box"></div>
</div>
<div id="snackbar">Message</div>

<div id="main" class="panel tabbed-panel compact-panel panel-primary container-fluid mt-4">

			<div class="tab-content">
			  <div class="tab-pane bg-white active" id="1">
 <input id="logtype" value="<?php echo htmlspecialchars(@$_SESSION['type']);?>" type="hidden">             

			  
<div class="products all"><?php include "products.php";?></div>			  			
<div class="customers all" style="display:none"><?php include "customers.php";?></div>
<div class="sales all" style="display:none"><?php include "sales.php";?></div>
<div class="pagecontent all" style="display:none"></div>
				
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-lg" style="height:auto" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Singa4real Cart</h5>
                <button type="button" class="close" aria-label="Close" onclick="closeModal()">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body loadorder">
             <iframe id="ifrm" src="{{curls}}" frameborder="0" scrolling="no" onload="autoResize('ifrm')" style="width: 100%;"></iframe> 
            </div>
           
        </div>
    </div>
</div>
	
	
				</div>

                
			</div>
  </div>
<script src="./js/wysiwyg.js?v=1" type="text/javascript"></script>
<script type="text/javascript" src="js/function.js?v=2"></script>
<script src="./js/validate.js" type="text/javascript"></script>
</body>
</html>
