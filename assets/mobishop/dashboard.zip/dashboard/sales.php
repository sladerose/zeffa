<?php
include "../config.php";	
?>
<div class="border-bottom mb-3 row">
<div class="col text-center"><h4><b>Sales</b></h4></div>
</div>
    <table id="datatable5" class="table  table-striped table-bordered dt-responsive nowrap display" cellspacing="0" width="100%">
    				<thead>
						<tr>
							<th width="30%">Trans. ID</th>
							<th width="30%">Amount</th>
							<th width="20%">Status</th>
							<th width="20%">Date</th>
							<th class="none">Payment Processor</th>
							<th class="none">Currency Paid With</th>
							<th class="none">Customer's Name</th>
							<th class="none">Email</th>
							<th class="none">Phone Number</th>
							<th class="none">Address</th>
							<th class="none">Action</th>
                        </tr>
					</thead>
					
</table>
<script>
$.fn.dataTable.ext.errMode = 'none';
   var table5 =  $('#datatable5').DataTable({ 
	  "ajax":{
        "url":"./saleslist.php?rnd=" + String((new Date()).getTime()).replace(/\D/gi, ''),
 "contentType":"application/json; charset=utf-8",
      "dataType":"json",
        "dataSrc": function ( json ) { 
		var valuesparent = $.map( json, function (value, key) { return value; });
        return valuesparent;
		  },
	"error": function (error) { 
		  }, 
      },
        "columns": [
		{ "data": "code" ,"defaultContent": "Not set"  },
		{ "data": "amount" ,"defaultContent": "Not set"  },
			{ "data": "status" ,"defaultContent": "Not set"  },
			{ "data": "day" ,"defaultContent": "Not set"  },
			{ "data": "pro" ,"defaultContent": "Not set"  },
			{ "data": "pcode" ,"defaultContent": "Not set"  },
		{ "data": "cname" ,"defaultContent": "Not set"  },
		{ "data": "email" ,"defaultContent": "Not set"  },
			{ "data": "phone" ,"defaultContent": "Not set"  },
			{ "data": "add" ,"defaultContent": "Not set"  },
			{ "data": "code" ,"defaultContent": "Not set"  },
        ],
		"columnDefs": [ {
    "targets": 10,
    "data": "download_link",
    "render": function ( data, type, row, meta ) {
	  return '<a class="btn dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b><i class="fa fa-indent"></i></b></a><div class="dropdown-menu" aria-labelledby="navbarDropdown"><a class="dropdown-item newlink btn-sm" href="#" id="./msales.php?salesid='+row.code+'" title="Update Sale"><i class="fa fa-edit text-blue"></i>&nbsp;&nbsp;Update Sales</a><a class="dropdown-item newlink btn-sm" href="#" id="./mtracking.php?orderid='+row.code+'" title="Update Tracking"><i class="fa fa-edit text-blue"></i>&nbsp;&nbsp;Update Tracking</a><a class="dropdown-item newlink btn-sm" href="#" id="./orderlist.php?orderid='+row.code+'" title="View Invoice"><i class="fa fa-edit text-blue"></i>&nbsp;&nbsp;View Invoice</a><a class="dropdown-item sendmessage btn-sm" href="#" title="Send Message"><i class="fa fa-envelope"></i>&nbsp;&nbsp;Send Message</a>';

	}
  }],
		deferRender: true,
		responsive: true,
		"autoWidth": false,
		dom: 'Bfrtip',
        buttons: [
        'pdf',
        'excel',
        'print'
    ]
		
  });
   $('#datatable5 tbody').on('click', '.updatesales', function (element) {
var tr = $(element.target).closest('tr');
        if(tr.hasClass('child'))
        {
            tr=$(tr).prev();
        }
        var datat = table5.row(tr).data();
		$(".pagecontent").empty();
		 $("#loader").show();
$(".pagecontent").load("./msales.php",function(){
		$("#staname").val(datat["name"]);
		$("#stacode").val(datat["code"]);
		$("#cclcodev").val(datat["clcode"]);
		$("#role").val(datat["role"]);
		$("#stagender").val(datat["gender"]);
		$("#staphone").val(datat["phone"]);
		$("#staemail").val(datat["email"]);
		$("#stabirth").val(datat["birth"]);
		$("#stadd").val(datat["add"]);
		$("#stuabout").val(datat["about"]);
		$("#clcode").val(datat["clcode"]);
		$("#clname").val(datat["clname"]); 
		$(".all").hide();
		$(".pagecontent").show();
		$(".loader").hide();
    } );
    } );
	$('#datatable5 tbody').on('click', '.sendmessage', function (element) {
var tr = $(element.target).closest('tr');
        if(tr.hasClass('child'))
        {
            tr=$(tr).prev();
        }
        var datat = table5.row(tr).data();
		$(".pagecontent").empty();
		 $("#loader").show();
$(".pagecontent").load("./sendmessage.php",function(){
		$("#email").val(datat["email"]);
		$("#rname").val(datat["cname"]);
		$(".all").hide();
		$(".pagecontent").show();
		$(".loader").hide();
    } );
    } );

</script>