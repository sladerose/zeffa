<?php
$filename = "./config.lock";
if (file_exists($filename)){
exit;
}
if(empty($_POST)){
exit;	
}
define('ROOTDIR', dirname(__FILE__));
define('LIBDIR', ROOTDIR);
define('CONFIG_FILE', './setup.php');

define('CE_NEWLINE', "\r\n");
define('CE_WORDWRAP', 20);
require_once(LIBDIR.'/confedit.class.php');

// Creating an instance of ConfigEditor
$config = new ConfigEditor();

    $config->SetVar('dashbard_database_path', $_POST["dbp"]."database/", 'Dashboard Database Path');
	$config->SetVar('cart_database_path', $_POST["dcp"]."database/", 'Cart Dashboard Path');
	$config->SetVar('payment_processor_database_path', $_POST["ppdp"]."database/", 'Payment Processor Database Path');
	$config->SetVar('email', $_POST["email"], 'Admin Login Email');
	$config->SetVar('pass', $_POST["pass"], 'Admin Lgin Password');
	$config->SetVar('theme', $_POST["theme"], 'Dashboard theme color');
	
	$config->SetVar('paypal_account_email', $_POST["pemail"], 'Paypal Account email');
	$config->SetVar('paypal_url', $_POST["ppurl"], 'PayPal server url');
	$config->SetVar('paypal_currency_code', $_POST["pcc"], 'PayPal currency code');
	$config->SetVar('paypal_success_url', $_POST["psurl"], 'Paypal success url');
	$config->SetVar('paypal_cancel_url', $_POST["pcurl"], 'Paypal cancel url');
	$config->SetVar('paypal_notify_url', $_POST["pnurl"], 'Paypal Notification url');
	
	$config->SetVar('payfast_url', $_POST["pfurl"], 'PayPal server url');
	$config->SetVar('payfast_notify_email', $_POST["pfemail"], 'PayFast Account email');
	$config->SetVar('payfast_mid', $_POST["pfmid"], 'PayFast Marchant ID');
	$config->SetVar('payfast_key', $_POST["pfkey"], 'PayFast Marchant Key');
	$config->SetVar('payfast_return_url', $_POST["pfsurl"], 'PayFast success url');
	$config->SetVar('payfast_cancel_url', $_POST["pfcurl"], 'PayFast cancel url');
	$config->SetVar('payfast_notify_url', $_POST["pfnurl"], 'PayFast Notification url');
	
	$config->SetVar('paystack_account_email', $_POST["psemail"], 'PayStack Account email');
	$config->SetVar('paystack_public_key', $_POST["pskey"], 'PayStack Public Key');
	$config->SetVar('paystack_secret_key', $_POST["psskey"], 'PayStack Secret Key');
	$config->SetVar('paystack_success_url', $_POST["pssurl"], 'PayStack success url');
	$config->SetVar('paystack_close_url', $_POST["pscurl"], 'PayStack cancel url');
	$config->Save(CONFIG_FILE);
    file_put_contents("./config.lock", "locked");
    header('Location: ./login.php');
    exit;   

?>