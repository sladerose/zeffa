<?php
include "./setup.php";
$settings	=  json_decode(@file_get_contents($cart_database_path."settings/data.json"), true);
$order	=  json_decode(@file_get_contents($cart_database_path."orders/".$_GET["orderid"].".json"), true);
$sales	=  json_decode(@file_get_contents($cart_database_path."sales/".$_GET["orderid"].".json"), true);
if(empty($sales["email"])){
echo "No Information Matched your Invoice ID";
exit();	
}
?>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Sales Invoice</title>
<link href="css/invoice.css?v=01" type="text/css" rel="stylesheet" />
</head>
<body>	
<div id="shopping-cart">
<div style="text-align: right; font-size:18px">Status: <?php echo "<span style='color: red;'>".$sales["status"]."</span>";?><br><br></div>
<table class="table" cellpadding="3" cellspacing="1" width="100%">	
<thead class="bg-primary">
<tr>
<th style="text-align:left; width: 50%">Name:</th>
<th style="text-align:left;">Phone:</th>
</tr>
<thead>
<tbody>
<tr>
<td><?php echo $sales["cname"];?></td>
<td><?php echo $sales["phone"];?></td>
</tr>
</tbody>
</table> 
<table cellpadding="3" cellspacing="1" width="100%" class="table" >	
<thead class="bg-primary">
<tr>
<th style="text-align:left; width: 50%">Email:</th>
<th style="text-align:left;">Address:</th>
</tr>
<thead>
<tbody>
<tr>
<td><?php echo $sales["email"];?></td>
<td><?php echo $sales["add"];?></td>
</tr>
</tbody>
</table> 
<?php
if(!empty($order)){
    $total_quantity = 0;
    $total_price = 0;
	$total_vat = 0;
	$total_shipping = 0;
?>	
<table  class="table table-striped"  cellpadding="3" cellspacing="1" width="100%">
<thead class="bg-primary">
<tr>
<th style="text-align:left;">Item</th>
<th style="text-align:right;" width="5%">Qty</th>
<th style="text-align:right;" width="15%">U-Price</th>
<th style="text-align:right;" width="15%">Total</th>
</tr>
</thead>
<tbody>
<?php		
    foreach ($order as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
				<tr>
				<td><?php echo $item["pname"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo $settings["picon"]."".number_format($item["price"],2); ?></td>
				<td  style="text-align:right;"><?php echo $settings["picon"]."". number_format($item_price,2); ?></td>
				</tr>
				<?php
				$total_vat += $item["vat"]*$item["quantity"];
				$total_shipping += ($item["shipping"]*$item["quantity"]);
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>
<?php
if($total_vat > 0){
?>
</tbody>
<tfoot>
<tr>
<td align="right" colspan="4"><strong>Vat:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $settings["picon"]."".number_format($total_vat, 2); ?></strong></td>
</tr>
<?php
}
?>
<?php
if($total_shipping > 0){
if($total_price > $settings["fsa"]){
$total_shipping = 0.00;
}elseif($total_shipping > $settings["msc"]){
$total_shipping = $settings["msc"];
}
?>
<tr>
<td align="right" colspan="4"><strong>Shipping:&nbsp;&nbsp;&nbsp;<?php echo $settings["picon"]."".number_format($total_shipping, 2); ?></strong></td>
</tr>
<?php
if($settings["ptax"] == "In.vat"){
$total_price = 	$total_price + $total_vat;
$tot = $settings["ptax"];
}elseif($settings["ptax"] == "Ex.vat"){
$tot = $settings["ptax"];
}else{
$tot = "";	
}
}
?>
<tr>
<td align="right" colspan="4"><strong>Total:&nbsp;&nbsp;&nbsp;<?php echo $settings["picon"]."".number_format($total_price, 2); ?>&nbsp;&nbsp;<span style="color: red"><?php echo $tot; ?></span></strong></td>

</tr>
</tfoot>
</table>
  <?php
}
?>


</div>

  <script>
$(document).on('click', '.print-in', function() {
   w=window.open();
w.document.write($('#shopping-cart').html());
w.print();
w.close();
  });

</script>
</body>
</html>

